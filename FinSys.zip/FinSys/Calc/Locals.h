#ifndef __locals_H


unsigned long	return_status	=	0; /*{ return_status is status returned by calls.}*/
//char		module_name[80];	/*{ module_name holds the name of the currently active module.}*/
#endif
