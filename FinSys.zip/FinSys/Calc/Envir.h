/* #define dirsep "\\"
#define maindev "c:" + dirsep
#define maindir maindev + dirsep + "tc" + dirsep + "dev" + dirsep + "bondsys" + dirsep
#define headdir maindir + "headers" + dirsep */

#define datehead "c:\tc\dev\bondsys\headers\datedec.h"
#define genhead "c:\tc\dev\bondsys\headers\gendec.h"
#define filespec(pathnam,filenam) pathnam + #filenam


