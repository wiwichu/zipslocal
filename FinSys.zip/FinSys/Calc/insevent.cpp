#include "stdafx.h"
#include "Insevent.h"

Inst_Event::Inst_Event ()
{
}
/*
Inst_Event::Inst_Event (CDB *DB_parm) : holidays_class (DB_parm)
{
	DB_local = DB_parm;

//	DB_local->InitDB();

//	DB_local->GetStatementHandle(&localhandles);
}
*/