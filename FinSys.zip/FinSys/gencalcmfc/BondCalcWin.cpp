// BondCalcWin.cpp : implementation file
//

#include "stdafx.h"
#include "gencalcmfc.h"
#include "BondCalcWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BondCalcWin

IMPLEMENT_DYNCREATE(BondCalcWin, CMDIChildWnd)

BondCalcWin::BondCalcWin()
{
}

BondCalcWin::~BondCalcWin()
{
}


BEGIN_MESSAGE_MAP(BondCalcWin, CMDIChildWnd)
	//{{AFX_MSG_MAP(BondCalcWin)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// BondCalcWin message handlers
