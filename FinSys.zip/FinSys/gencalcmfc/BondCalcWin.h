#if !defined(AFX_BONDCALCWIN_H__6F866681_5A69_11D1_8F5B_444553540000__INCLUDED_)
#define AFX_BONDCALCWIN_H__6F866681_5A69_11D1_8F5B_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// BondCalcWin.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// BondCalcWin frame

class BondCalcWin : public CMDIChildWnd
{
	DECLARE_DYNCREATE(BondCalcWin)
protected:
	BondCalcWin();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(BondCalcWin)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~BondCalcWin();

	// Generated message map functions
	//{{AFX_MSG(BondCalcWin)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BONDCALCWIN_H__6F866681_5A69_11D1_8F5B_444553540000__INCLUDED_)
